from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import torch, math, io, base64
from torchvision import transforms
from model import GameAssetAutoencoder

app = Flask(__name__)
CORS(app)

model = GameAssetAutoencoder()
model.load_state_dict(torch.load("game_asset_autoencoder.pth", map_location="cpu"))
model.eval()

transform = transforms.Compose([transforms.Resize((64,64)), transforms.ToTensor()])

@app.route("/")
def home():
    return jsonify({"message":"Game Asset Autoencoder Backend is Running!"})

@app.route("/reconstruct", methods=["POST"])
def reconstruct():
    if "image" not in request.files:
        return jsonify({"error":"No image uploaded"}), 400
    image = Image.open(request.files["image"]).convert("RGB")
    x = transform(image).unsqueeze(0)

    with torch.no_grad():
        latent = model.encoder(x)
        mn, mx = latent.min(), latent.max()
        q = (((latent-mn)/(mx-mn+1e-8))*255).round().to(torch.uint8)
        restored = q.float()/255.0*(mx-mn)+mn
        recon = model.decoder(restored)

    mse = torch.mean((x-recon)**2).item()
    psnr = float("inf") if mse == 0 else 10*math.log10(1/mse)

    out = transforms.ToPILImage()(recon.squeeze(0).clamp(0,1))
    buf = io.BytesIO()
    out.save(buf, format="PNG")
    b64 = base64.b64encode(buf.getvalue()).decode()

    original_bytes = 64*64*3
    latent_bytes = q.numel()

    return jsonify({
        "message":"Image reconstructed successfully",
        "reconstructed_image":"data:image/png;base64,"+b64,
        "input_size":"64 × 64 RGB",
        "latent_shape":list(latent.shape),
        "latent_values":int(latent.numel()),
        "original_size_bytes":original_bytes,
        "latent_size_bytes":latent_bytes,
        "compression_ratio":round(original_bytes/latent_bytes,2),
        "mse":round(mse,6),
        "psnr":round(psnr,2)
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
