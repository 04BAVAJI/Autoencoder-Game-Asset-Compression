# Autoencoder Compression for Game Assets

A Semester 3 Deep Learning project demonstrating image compression and reconstruction using a convolutional autoencoder.

## Dataset
600 synthetic 64×64 RGB images:
- Character: 150
- Vehicle: 150
- Weapon: 150
- Environment: 150

These four categories are dataset categories. The autoencoder is **not a four-class classifier**.

## Architecture
`3×64×64 → 32×32×32 → 64×16×16 → 128×8×8 → decoder → 3×64×64`

Latent representation: `128×8×8 = 8,192 values`.

## Training
- PyTorch
- MSE loss
- Adam optimizer
- Learning rate: 0.001
- Batch size: 32
- 10 initial + 20 additional epochs

## Evaluation
- MSE
- PSNR
- Raw latent representation ratio

Raw comparison:
- Original RGB: 12,288 bytes
- Quantized latent: 8,192 bytes
- Ratio: 1.50×

This is a representation-level ratio and excludes model weights, metadata and file overhead.

Example quantized result:
- MSE ≈ 0.005649
- PSNR ≈ 22.48 dB

## Limitation
Some reconstructions are slightly blurry because compression removes fine details and the current dataset/model are relatively simple. Larger datasets, improved architectures and perceptual losses are possible future work.

## Web Demo
`Upload → Encoder → Quantized Latent → Decoder → Reconstruction → Metrics`

Backend: Flask
Frontend: HTML/CSS/JavaScript

## Run
Put `game_asset_autoencoder.pth` inside `backend/`, then run:

```powershell
.env\Scripts\python.exe app.py
```

Open `frontend/index.html` in a browser.
