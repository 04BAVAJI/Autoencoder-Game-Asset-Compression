# Project Report — Autoencoder Compression for Game Assets

## 1. Problem Statement
Create an overcomplete autoencoder designed to reduce the storage footprint of virtual in-game items while preserving visual fidelity.

## 2. Objective
To encode game-asset images into a latent representation, demonstrate reduced raw representation size through 8-bit latent quantization, reconstruct the image, and evaluate reconstruction quality.

## 3. Dataset
600 synthetic images were created in four categories: character, vehicle, weapon and environment, with 150 images per category.

## 4. Preprocessing
Images were converted to RGB, resized to 64×64 pixels and converted to tensors. The dataset used an 80/20 split: 480 training images and 120 testing images.

## 5. Autoencoder
Encoder:
3×64×64 → 32×32×32 → 64×16×16 → 128×8×8.

Decoder:
128×8×8 → 64×16×16 → 32×32×32 → 3×64×64.

The latent representation contains 8,192 values.

## 6. Training
PyTorch was used with MSE loss and the Adam optimizer. Learning rate was 0.001 and batch size was 32. The model was trained for an initial 10 epochs and then 20 additional epochs.

## 7. Compression
The latent representation was normalized and quantized to uint8 values. The raw representation comparison is:
12,288 bytes original RGB / 8,192 bytes quantized latent = 1.50×.

This does not represent final file compression because model weights, metadata and file overhead are excluded.

## 8. Evaluation
MSE measures reconstruction error, while PSNR measures reconstruction quality in decibels. An example quantized reconstruction produced approximately MSE 0.005649 and PSNR 22.48 dB; values vary with the input.

## 9. Results
The system successfully encodes and reconstructs images and exposes the result through a Flask web application. Some outputs are slightly blurry, which is a current reconstruction-quality limitation.

## 10. Web Application
The demo provides image upload, reconstruction, original/reconstructed image display, latent information, MSE, PSNR, compression ratio and reconstructed-image download.

## 11. Limitations and Future Work
The current synthetic dataset is relatively small and the model is simple. Future work can use a larger real-world dataset, improved architectures, longer training, hyperparameter tuning and perceptual reconstruction losses. A complete compressed latent-file format including metadata could also be implemented.

## 12. Conclusion
The project demonstrates an autoencoder-based approach for representing game assets with a compact latent representation and reconstructing them while retaining the main visual structure.
